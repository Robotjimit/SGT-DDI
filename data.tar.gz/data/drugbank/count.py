import pandas as pd

# 读取CSV文件
csv_file_path = 'ddis.csv'
df = pd.read_csv(csv_file_path)

# 统计'type'列的每个类别的个数
type_counts = df['type'].value_counts()

# 打印每个类别的个数
print(type_counts)

# 如果需要，可以将结果保存到一个新的CSV文件中
type_counts.to_csv('type_counts.csv')